#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../include/utils.h"
#include "../include/data_manager.h"

// Simple file logger to help diagnose unexpected exits
static void log_step(const char* msg) {
    FILE* f = fopen("tests_results.txt", "a");
    if (!f) return;
    fprintf(f, "%s\n", msg);
    fclose(f);
}

// Simple test helpers
static int tests_run = 0;
static int tests_failed = 0;

#define ASSERT(cond, msg) do { \
    tests_run++; \
    if (!(cond)) { \
        printf("[FAIL] %s\n", msg); \
        tests_failed++; \
    } else { \
        printf("[ OK ] %s\n", msg); \
    } \
} while(0)

void test_validate_date_string() {
    ASSERT(validate_date_string("2023-01-01") == 1, "valid date 2023-01-01");
    ASSERT(validate_date_string("2023-02-29") == 0, "invalid leap date 2023-02-29");
    ASSERT(validate_date_string("2000-02-29") == 1, "valid leap date 2000-02-29");
    ASSERT(validate_date_string("20230101") == 0, "invalid format no dashes");
}

void test_validate_time_string() {
    ASSERT(validate_time_string("09:30") == 1, "valid time 09:30");
    ASSERT(validate_time_string("24:00") == 0, "invalid hour 24:00");
    ASSERT(validate_time_string("9:30") == 0, "invalid format 9:30");
}

void test_calculate_time_difference() {
    float d1 = calculate_time_difference("09:00", "17:00");
    ASSERT((int)(d1*10) == 80, "8.0 hours between 09:00 and 17:00");
    float d2 = calculate_time_difference("23:00", "01:00");
    ASSERT((int)(d2*10) == 20, "2.0 hours across midnight 23:00-01:00");
}

void test_data_manager_add_modify_delete() {
    int count = 0;
    // allocate buffer on heap to match init_attendance_data expectations
    AttendanceRecord* records = (AttendanceRecord*)malloc(MAX_RECORDS * sizeof(AttendanceRecord));
    if (!records) {
        printf("[FAIL] memory alloc failed\n");
        tests_failed++;
        return;
    }
    init_attendance_data(records, &count);
    ASSERT(count == 0, "init sets count to 0");

    AttendanceRecord r;
    memset(&r,0,sizeof(r));
    strncpy(r.ID, "E001", MAX_EMPLOYEE_ID-1);
    strncpy(r.name, "Test", MAX_EMPLOYEE_ID-1);
    strncpy(r.date, "2023-12-01", 10);
    r.attendance_status = NORMAL;
    r.work_hours = 8.0f;

    int ok = add_attendance_record(records, &count, &r);
    ASSERT(ok == 1 && count == 1 && strcmp(records[0].ID, "E001")==0, "add record works");

    int idx = find_record_index(records, count, "E001", "2023-12-01");
    ASSERT(idx == 0, "find_record_index returns 0");

    AttendanceRecord upd = records[0];
    strncpy(upd.name, "Updated", MAX_EMPLOYEE_ID-1);
    int m = modify_attendance_record(records, count, 0, &upd);
    ASSERT(m == 1 && strcmp(records[0].name, "Updated") == 0, "modify record updates name");

    // Avoid calling interactive delete_record_by_index in automated tests.
    // Perform deletion logic directly to verify removal behavior.
    if (count > 0) {
        for (int i = 0; i < count - 1; i++) {
            records[i] = records[i + 1];
        }
        count--;
    }
    ASSERT(count == 0, "manual delete decreases count");
    free(records);
}

int main(void) {
    // Disable stdout buffering to ensure messages appear in console immediately
    setvbuf(stdout, NULL, _IONBF, 0);

    log_step("TEST START");
    printf("Running tests...\n");

    log_step("start test_validate_date_string");
    test_validate_date_string();
    log_step("end test_validate_date_string");

    log_step("start test_validate_time_string");
    test_validate_time_string();
    log_step("end test_validate_time_string");

    log_step("start test_calculate_time_difference");
    test_calculate_time_difference();
    log_step("end test_calculate_time_difference");

    log_step("start test_data_manager_add_modify_delete");
    test_data_manager_add_modify_delete();
    log_step("end test_data_manager_add_modify_delete");
    printf("\nTests run: %d, Failures: %d\n", tests_run, tests_failed);

    // Pause so the console window stays open when run by double-click
    printf("\n���س����˳�...\n");
    fflush(stdout);
    // Consume any leftover input
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
    // Wait for final Enter
    getchar();

    return tests_failed == 0 ? 0 : 1;
}
